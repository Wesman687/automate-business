'use client';

import FinancialPage from '@/components/FinancialPage';

export default function AdminFinancialPage() {
  return <FinancialPage />;
}
