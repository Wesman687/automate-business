'use client';

import JobManagementPage from '@/components/JobManagementPage';

export default function AdminJobsPage() {
  return <JobManagementPage />;
}
